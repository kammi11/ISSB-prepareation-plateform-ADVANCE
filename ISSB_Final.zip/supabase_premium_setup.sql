-- ═══════════════════════════════════════════════════════════════
--  ISSB MASTER — Premium / Easypaisa Payment Feature
--  Run this in Supabase → SQL Editor AFTER supabase_setup.sql
--  ⚠ Replace 'YOUR-ADMIN-EMAIL@example.com' below with your real
--    admin email (the same one you use for ADMIN_EMAILS in the HTML)
--    in BOTH places it appears before running.
-- ═══════════════════════════════════════════════════════════════

-- 1) Add a premium flag to profiles
alter table public.profiles add column if not exists is_premium boolean default false;

-- Prevent users from setting their own is_premium = true (only the
-- admin account, checked by email, may change it — normally this
-- happens when you click "Approve" in the Admin panel)
create or replace function protect_premium_flag()
returns trigger as $$
begin
  if new.is_premium is distinct from old.is_premium then
    if coalesce(auth.jwt() ->> 'email', '') <> 'aqaim2915@gmail.com' then
      new.is_premium := old.is_premium;
    end if;
  end if;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists protect_premium_flag_trigger on public.profiles;
create trigger protect_premium_flag_trigger
  before update on public.profiles
  for each row execute function protect_premium_flag();


-- 2) Payment requests table
create table if not exists public.payment_requests (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete cascade,
  email text,
  amount numeric,
  sender_number text,
  transaction_id text,
  screenshot_url text,
  status text default 'pending' check (status in ('pending','approved','rejected')),
  admin_note text,
  created_at timestamptz default now(),
  reviewed_at timestamptz
);

alter table public.payment_requests enable row level security;

-- A signed-in user can submit their own payment request
create policy "payment_requests: user can insert own"
  on public.payment_requests for insert
  with check (auth.uid() = user_id);

-- A user can see their own requests (to show "pending review" status)
create policy "payment_requests: user can read own"
  on public.payment_requests for select
  using (auth.uid() = user_id);

-- Only the admin account can see every request
create policy "payment_requests: admin can read all"
  on public.payment_requests for select
  using (coalesce(auth.jwt() ->> 'email', '') = 'aqaim2915@gmail.com');

-- Only the admin account can approve/reject (update status)
create policy "payment_requests: admin can update"
  on public.payment_requests for update
  using (coalesce(auth.jwt() ->> 'email', '') = 'aqaim2915@gmail.com');


-- 3) Storage bucket for payment screenshots
--    NOTE: run this, then ALSO go to Storage → payment-screenshots →
--    make sure "Public bucket" is turned ON (so screenshot links work
--    in the Admin panel). If the insert below errors because the
--    bucket already exists, that's fine — ignore it.
insert into storage.buckets (id, name, public)
values ('payment-screenshots', 'payment-screenshots', true)
on conflict (id) do nothing;

-- Any signed-in user can upload their own screenshot
create policy "payment screenshots: signed-in users can upload"
  on storage.objects for insert
  with check (bucket_id = 'payment-screenshots' and auth.role() = 'authenticated');

-- Public bucket = anyone with the link can view (needed so the
-- <img> preview works in the Admin panel and for the user themself)
create policy "payment screenshots: public can view"
  on storage.objects for select
  using (bucket_id = 'payment-screenshots');
